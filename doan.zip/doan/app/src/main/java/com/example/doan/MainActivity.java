package com.example.doan;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView lv;
    ArrayList<Work1> list;
    ArrayList<Work1> list1;
    EditText editText;
    Button btn;
    ArrayList<Work> objectlist;
   CustomerTitleAdapter adapter;
   CustomerTitleAdapter adapter1;
    String url = "";
    String dau="https://careerbuilder.vn/viec-lam/tat-ca-viec-lam-";
    int n = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lv = (ListView) findViewById(R.id.lv);
        editText = (EditText) findViewById(R.id.key);
        objectlist = new ArrayList<Work>();
        list=new ArrayList<Work1>();
        list1=new ArrayList<Work1>();
        adapter = new CustomerTitleAdapter(list, MainActivity.this);
        adapter1=new CustomerTitleAdapter(list1,MainActivity.this);
        lv.setAdapter(adapter);
        for(int i=1;i<150;i++){
            if(i==1){
                url=(new StringBuilder()).append(dau).append("vi").append(".html").toString();
            }
            else {
                url = (new StringBuilder()).append(dau).append("trang-" + i + "-vi").append(".html").toString();
            }
            getData(url);

        }
        btn = (Button) findViewById(R.id.search_go_btn);
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(charSequence.toString().equals("")){
                  list1.clear();
                  for(Work work:objectlist){
                      list.add(new Work1(work.getTitle(),work.getImg()));
                  }
                   adapter.notifyDataSetChanged();
                  lv.setAdapter(adapter);
                   // adapter.notifyDataSetChanged();
                }


            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        OnclickLis();
        OnClickItem();

    }
    private void getData(String url) {
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        final StringRequest stringRequest = new StringRequest(Request.Method.GET, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Document doc = Jsoup.parse(response);
                if (doc != null) {
                    Elements elements = doc.select("dd.brief");
                   // Toast.makeText(MainActivity.this, elements.size()+"", Toast.LENGTH_LONG).show();
                    for (Element element : elements) {
                        Element element1 = element.getElementsByTag("h3").first();
                        Element element2= element.getElementsByTag("img").first();
                        Element element3= element.getElementsByClass("namecom").first();
                        Element element4=element.getElementsByClass("location").first();
                        Element element5=element.getElementsByClass("salary").first();
                        Element element6= element.select("h3.job>a").first();

                        objectlist.add(new Work(element1.text(),element3.text(),element5.text(),element4.text(),element2.attr("data-original"),element6.attr("href")));
                        list.add(new Work1(element1.text(),element2.attr("data-original")));
                    }
                    adapter.notifyDataSetChanged();
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this, "Lỗi", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        requestQueue.add(stringRequest);
    }

    public void OnclickLis() {
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (editText.getTextSize()>0) {
                    list.clear();
                    for (Work work : objectlist) {
                        if (work.getTitle().toLowerCase().contains(editText.getText().toString().toLowerCase())==true ) {
                            list1.add(new Work1(work.getTitle(),work.getImg()));

                        }
                    }
                    //  Work getWork = findwork(editText.getText().toString().toLowerCase());

                    //Toast.makeText(MainActivity.this,getWork.getTitle() , Toast.LENGTH_SHORT).show();
                    adapter1.notifyDataSetChanged();
                    lv.setAdapter(adapter1);
                }
               // else {
                 //   for(Work work:objectlist){
                  //      list.add(new Work1(work.getTitle(),work.getImg()));
                   // }
                   // adapter.notifyDataSetChanged();
                //}
            }
        });
    }
 public  void OnClickItem(){
 lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
     @Override
     public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
         if(adapter.arrayList.size()>0) {
             String item = adapter.arrayList.get(i).gettitle();
             Toast.makeText(MainActivity.this, item, Toast.LENGTH_SHORT).show();
             Work getwork = findwork(item);
             Intent intent = new Intent(MainActivity.this, OnClickItem.class);
             intent.putExtra("WORK", getwork);
             startActivity(intent);
         }
         if(adapter1.arrayList.size()>0){
             String item = adapter1.arrayList.get(i).gettitle();
             Toast.makeText(MainActivity.this, item, Toast.LENGTH_SHORT).show();
             Work getwork = findwork(item);
             Intent intent = new Intent(MainActivity.this, OnClickItem.class);
             intent.putExtra("WORK", getwork);
             startActivity(intent);
         }
     }
 });
 }

public Work findwork(String name) {
    for (Work work: objectlist)
       if (work.getTitle().equals(name) == true) {
            return work;
        }
    return null;
}

}
