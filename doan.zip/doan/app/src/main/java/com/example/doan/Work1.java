package com.example.doan;

import java.io.Serializable;

public class Work1 implements Serializable {
    private String Title;
    private  String Img;

    public Work1(String title, String img) {
        Title = title;
        Img = img;
    }
    public Work1(){

    }

    public String gettitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getimg() {
        return Img;
    }

    public void setImg(String img) {
        Img = img;
    }
}
