package com.example.doan;

import java.io.Serializable;

public class Work implements Serializable {
    private  String title;
    private  String company;
    private String prettySalary;
    private String location;
    private String img;
    private String url;

    public Work( String title,  String company, String prettySalary, String location, String img,String url) {

        this.title = title;
        this.company = company;
        this.prettySalary = prettySalary;
        this.location = location;
        this.img = img;
        this.url=url;
    }
    public Work(){

    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getPrettySalary() {
        return prettySalary;
    }

    public void setPrettySalary(String prettySalary) {
        this.prettySalary = prettySalary;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }
}
