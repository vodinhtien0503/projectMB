package com.example.doan;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.doan.R;
import com.squareup.picasso.Picasso;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.util.ArrayList;

public class OnClickItem extends AppCompatActivity {
    TextView txname,txcompany,txlocation,txsalary,txurl;
    ImageView img;
   @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.onclickitem);
         txname=(TextView)findViewById(R.id.tvname);
         txcompany=(TextView) findViewById(R.id.tvcompany);
         txlocation=(TextView)findViewById(R.id.tvlocation);
         txsalary=(TextView)findViewById(R.id.tvsalary);
         img=(ImageView)findViewById(R.id.img);
         txurl=(TextView)findViewById(R.id.tvurl) ;
       Intent intent=getIntent();
       Work data=(Work) intent.getSerializableExtra("WORK");
       Picasso.with(this).load(data.getImg()).into(img);
       txname.setText(data.getTitle()+"");
       txcompany.setText("Công ty: " +data.getCompany()+"");
       txlocation.setText("Địa chỉ : "+data.getLocation()+"");
       txsalary.setText(data.getPrettySalary()+"");
       txurl.setText("Nộp hồ sơ tại : "+data.getUrl()+"");

   }

}
